#Movie: Contains details about the movies. The specific attributes will depend on the
#information provided by the external API.
#Attributes: ID, title, runtime, rating, showtimes , status, average_rating, feedback_list.
class Movie:
    def __init__(self, movie_id, title, runtime, rating, showtimes, status, average_rating=0.0, feedback_list=None):
        self.movie_id = movie_id
        self.title = title
        self.runtime = runtime
        self.rating = rating
        self.showtimes = showtimes
        self.status = status
        self.average_rating = average_rating
        self.feedback_list = feedback_list if feedback_list else []

    def update_status(self, new_status):
        self.status = new_status

    def update_average_rating(self, new_rating):
        total_ratings = sum(feedback.rating for feedback in self.feedback_list)
        total_ratings += new_rating
        self.average_rating = total_ratings / (len(self.feedback_list) + 1) 

    def add_feedback(self, feedback):
        self.feedback_list.append(feedback)