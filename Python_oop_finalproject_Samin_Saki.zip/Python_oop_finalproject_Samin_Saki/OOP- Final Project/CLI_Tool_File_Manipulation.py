import argparse
import os
import json
import shutil
import datetime

class FileManipulator:
    def __init__(self, working_dir_file='path.json', log_file='logs.log'):
        self.working_dir_file = working_dir_file
        self.log_file = log_file

    def setup_parser(self):
        parser = argparse.ArgumentParser(description="File manipulation and directory navigation CLI tool")
        parser.add_argument("command", help="Command to execute (ls, cd, mkdir, rmdir, rm, cp, mv, find, cat)")
        parser.add_argument("path", nargs='?', default='.', help="Path for the command, defaults to current directory")
        parser.add_argument("destination", nargs='?', help="Destination path for cp, mv commands")
        parser.add_argument("-p", "--pattern", help="Pattern for the find command")
        parser.add_argument("-r", "--recursive", help="Recursive option for rm command")
        parser.add_argument("-f", "--file", help="File name for cat command")
        parser.add_argument("-a", "--all", action="store_true", help="Show all files and dirs.")
        return parser

    def is_valid_path(self, path):
        if not os.path.exists(path):
            print(f"Error: The path '{path}' does not exist.")
            return False
        if not os.access(path, os.R_OK):
            print(f"Error: The path '{path}' is not accessible.")
            return False
        return True

    def log_command(self, command, status, error_message=None):
        with open(self.log_file, 'a') as log:
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            log.write(f"{timestamp} - Command: {command}, Status: {status}")
            if error_message:
                log.write(f", Error: {error_message}")
            log.write('\n')

    def load_working_directory(self):
        if os.path.exists(self.working_dir_file):
            with open(self.working_dir_file, 'r') as f:
                data = json.load(f)
                return data.get('cwd', os.getcwd())
        return os.getcwd()

    def save_working_directory(self, path):
        with open(self.working_dir_file, 'w') as f:
            json.dump({'cwd': path}, f)

    def list_directory(self, path, show_hidden=False):
        cwd = self.load_working_directory()
        full_path = os.path.join(cwd, path)
        if not self.is_valid_path(full_path):
            return

        try:
            for item in os.listdir(full_path):
                if show_hidden or not item.startswith('.'):
                    print(item)
        except FileNotFoundError:
            print(f"Error: The directory '{cwd}' was not found.")

    # ... (other methods go here)

    def main(self):
        parser = self.setup_parser()
        args = parser.parse_args()
        try:
            if args.command == 'ls':
                if args.all:
                    self.list_directory(args.path, show_hidden=True)
                else:
                    self.list_directory(args.path)
            # ... (other commands go here)
            else:
                self.log_command(args.command, "Error", "Invalid command")
                print("Invalid Command!")
            self.log_command(args.command, "Success")
        except Exception as e:
            print(f"Error: {e}")
            self.log_command(args.command, "Error", str(e))

if __name__ == "__main__":
    file_manipulator = FileManipulator()
    file_manipulator.main()