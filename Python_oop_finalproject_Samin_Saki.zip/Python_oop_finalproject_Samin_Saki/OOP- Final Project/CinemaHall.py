#Cinema Reservation System (OOP)
#CinemaHall: Represents the cinema space, maintaining a list of movies and employees.
#Attributes: name, total_seats, movies_showing.
class CinemaHall:
    def __init__(self, name, total_seats):
        self.name = name
        self.total_seats = total_seats
        self.movies_showing = []

    def add_movie(self, movie):
        self.movies_showing.append(movie)

    def check_seat_availability(self, showtime):
        # Implement logic to check available seats for a given showtime
        pass

    def display_available_showtimes(self):
        # Display showtimes with available seats
        pass

    def make_reservation(self, user, movie, showtime, seat_number):
        # Implement logic to create a reservation
        pass
