#User (Inherits from Person): Manages customer-specific actions within the system.
#Attributes: user_id, reservations
from Person import *
class User(Person):
    def __init__(self, name, email, phone, user_id):
        super().__init__(name, email, phone)
        self.user_id = user_id
        self.reservations = []

    def view_reservations(self):
        # Display user's reservations
        pass

    def provide_feedback(self, movie, rating, comments):
        # Allow users to provide feedback for a movie
        pass