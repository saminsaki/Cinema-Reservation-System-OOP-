#Person (Base Class): Common details for individuals related to the cinema.
#Attributes: name, email, phone.

class Person:
    def __init__(self, name, email, phone):
        self.name = name
        self.email = email
        self.phone = phone