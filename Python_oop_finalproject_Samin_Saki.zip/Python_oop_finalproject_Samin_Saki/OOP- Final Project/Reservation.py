#Manages booking details, linking a user to a specific movie and showtime.
#Attributes: reservation_id, movie_id, showtime, seat_number, user_name.
class Reservation:
    def __init__(self, reservation_id, movie_id, showtime, seat_number, user_name):
        self.reservation_id = reservation_id
        self.movie_id = movie_id
        self.showtime = showtime
        self.seat_number = seat_number
        self.user_name = user_name
    def display_reservation_details(self):
        # Display reservation details, can be used for confirmation messages
        print(f"Reservation ID: {self.reservation_id}")
        print(f"Movie ID: {self.movie_id}")
        print(f"Showtime: {self.showtime}")
        print(f"Seat Number: {self.seat_number}")
        print(f"User: {self.user_name}")

    # Additional methods for handling reservation-related actions can be added as needed.
    def modify_reservation(self, new_showtime, new_seat_number):
        # Modify reservation details
        self.showtime = new_showtime
        self.seat_number = new_seat_number
        print("Reservation modified successfully.")

    def cancel_reservation(self):
        # Implement logic to cancel a reservation
        print("Reservation canceled.")