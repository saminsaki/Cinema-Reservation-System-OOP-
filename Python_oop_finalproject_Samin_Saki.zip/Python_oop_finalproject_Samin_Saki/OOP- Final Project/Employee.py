#Employee (Inherits from Person):Handles cinema operations and adds new movies via an API.
#Attributes: employee_id, position.
from Person import *
class Employee(Person):
    def __init__(self, name, email, phone, employee_id, position):
        super().__init__(name, email, phone)
        self.employee_id = employee_id
        self.position = position

    def add_new_movie(self, movie):
        # Implement logic to add a new movie to the cinema hall
        pass

    def manage_schedule(self, movie, new_showtimes):
        # Implement logic to update movie showtimes
        pass