#Feedback: Customer feedback for a movie.
#Attributes: user_id, movie_id, rating, comments.

class Feedback:
    def __init__(self, user_id, movie_id, rating, comments):
        self.user_id = user_id
        self.movie_id = movie_id
        self.rating = rating
        self.comments = comments




