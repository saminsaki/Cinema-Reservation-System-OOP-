# Cinema Reservation System
This is a cinema reservation system developed using Python.

## Instalation 
- Clone the repository 
- Install dependencies with 'pip install -r requirements.txt'

## Usage 
- Run 'python main.py' to start the application.

## Contributing
Pull requests are welcome. for major changes, please open  an  issue first to discuss what you would like to change.

